//============================================================================
// Project     : Lab2
// Name        : Helper401to500.java
// Author      : Tianqi Yang
// Time        : 4/18/2019
// IDE         : Eclipse
//Description : it is helper functions that fix error number from 401 to 500 
// that occurs in thread package
//============================================================================
package exception;

public class Helper401to500 {

}
