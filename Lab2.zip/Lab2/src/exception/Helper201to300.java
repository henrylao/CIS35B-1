//============================================================================
// Project     : Lab2
// Name        : Helper201to300.java
// Author      : Tianqi Yang
// Time        : 4/18/2019
// IDE         : Eclipse
//Description : it is helper functions that fix error number from 201 to 300 
// that occurs in exception package
//============================================================================
package exception;

public class Helper201to300 {

	public String fix201() {
        System.exit(1);
		return null;
	}
}
