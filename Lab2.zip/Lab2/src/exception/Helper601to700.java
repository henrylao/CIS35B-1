//============================================================================
// Project     : Lab2
// Name        : Helper601to700.java
// Author      : Tianqi Yang
// Time        : 4/18/2019
// IDE         : Eclipse
//Description : it is helper functions that fix error number from 601 to 700 
// that occurs in web package
//============================================================================
package exception;

public class Helper601to700 {

}
