//============================================================================
//Project     : Lab2
//Name        : FixAuto.java
//Author      : Tianqi Yang
//Time        : 4/18/2019
//IDE         : Eclipse
//Description : it is the interface of AutoExceotion
//============================================================================
package adapter;

public interface FixAuto {
	public String fix();
	public String fix(int i);
}