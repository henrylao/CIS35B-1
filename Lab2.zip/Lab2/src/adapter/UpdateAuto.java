package adapter;

public interface UpdateAuto {
	public void updateOptionSetName(String Modelname, String OptionSetname, String newName);
	public void updateOptionPrice(String ModelName, String optionName, String Option, float newPrice);
}