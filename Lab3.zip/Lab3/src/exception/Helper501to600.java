//============================================================================
// Project     : Lab3
// Name        : Helper501to600.java
// Author      : Tianqi Yang
// Time        : 5/6/2019
// IDE         : Eclipse
//Description : it is helper functions that fix error number from 501 to 600 
// that occurs in socket package
//============================================================================
package exception;

public class Helper501to600 {

}
