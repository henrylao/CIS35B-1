REM Task2.sql

REM DROP TABLE Printer;

CREATE TABLE Printer (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT Printer_PK PRIMARY KEY (id));
	
INSERT INTO Printer VALUES (1, 'Epson Stylus C86 Ink Jet Printer', 99.00);
INSERT INTO Printer VALUES (2, 'HP DeskJet 5650 Color Inkjet Printer', 129.99);

CREATE TABLE CPU (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT CPU_PK PRIMARY KEY (id));

INSERT INTO CPU VALUES (1, 'Intel Celeron Processor 2.4GHz', 87.99);
INSERT INTO CPU VALUES (2, 'AMD Opteron 140 pib', 217.99);

CREATE TABLE Memory (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT Memory_PK PRIMARY KEY (id));

INSERT INTO Memory VALUES (1, 'Crucial Tech 512MB', 79.99);
INSERT INTO Memory VALUES (2, 'Lexar Media 1GB SD card', 86.00);

CREATE TABLE CDDrive (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT CDDrive_PK PRIMARY KEY (id));

INSERT INTO CDDrive VALUES (1, 'Sony Internal CD Drive', 85.99);
INSERT INTO CDDrive VALUES (2, 'Iomega External CD Drive', 98.99);

CREATE TABLE HardDrive (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT HardDrive_PK PRIMARY KEY (id));

INSERT INTO HardDrive VALUES (1, 'Western Digital 80GB Hard Drive', 54.99);
INSERT INTO HardDrive VALUES (2, 'Seagate 40GB Barracuda Hard Drive', 55.95);

CREATE TABLE VideoCard (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT VideoCard_PK PRIMARY KEY (id));

INSERT INTO VideoCard VALUES (1, 'ATI Radeon 9250 256MB PCI Video Card', 129.00);
INSERT INTO VideoCard VALUES (2, 'XFX Graphics GeForce FX 5200', 61.95);

CREATE TABLE PowerSupply (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT PowerSupply_PK PRIMARY KEY (id));

INSERT INTO PowerSupply VALUES (1, 'Logisys 500W Transparent Power Supply', 49.00);
INSERT INTO PowerSupply VALUES (2, 'Achieve AX500N 500W Power Supply', 28.00);

CREATE TABLE Speaker (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT Speaker_PK PRIMARY KEY (id));

INSERT INTO Speaker VALUES (1, 'CreativeLab SBS250 Speakers', 16.00);
INSERT INTO Speaker VALUES (2, 'Benwin S54 Surround Sound Speakers', 29.00);

CREATE TABLE SoundCard (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT SoundCard_PK PRIMARY KEY (id));

INSERT INTO SoundCard VALUES (1, 'SB Audigy 2 ZS Sound Card', 89.00);
INSERT INTO SoundCard VALUES (2, 'Sound Blaster Digital Sound Card', 19.00);

CREATE TABLE Monitor (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT Monitor_PK PRIMARY KEY (id));

INSERT INTO Monitor VALUES (1, 'AOC LM520 Flat Screen 15" Monitor', 229.00);
INSERT INTO Monitor VALUES (2, 'Acer 15" Flat Screen Monitor', 175.00);

CREATE TABLE Keyboard (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT Keyboard_PK PRIMARY KEY (id));

INSERT INTO Keyboard VALUES (1, 'Labtec Standard Keyboard', 8.00);
INSERT INTO Keyboard VALUES (2, 'Logitech Cordless Access Duo Optical', 45.00);

CREATE TABLE Mouse (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT Mouse_PK PRIMARY KEY (id));

INSERT INTO Mouse VALUES (1, 'Logitech Optical Mouse', 16.00);
INSERT INTO Mouse VALUES (2, 'Microsoft Wireless Optical Mouse', 38.00);

CREATE TABLE FloppyDrive (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT FloppyDrive_PK PRIMARY KEY (id));

INSERT INTO FloppyDrive VALUES (1, 'Mitsumi 1.44 Floppy Drive (Black)', 10.00);
INSERT INTO FloppyDrive VALUES (2, 'Sony 1.44 Floppy Drive (White)', 14.00);

CREATE TABLE EthernetCard (
	id NUMBER(4) NOT NULL,
	name CHAR(40),
	cost NUMBER(7,2),
	CONSTRAINT EthernetCard_PK PRIMARY KEY (id));

INSERT INTO EthernetCard VALUES (1, '3Com Etherlink III', 48.00);
INSERT INTO EthernetCard VALUES (2, 'Danpex EN Network Card', 45.00);
