// Motherboard.java

import java.io.*;

/**
Motherboard
*/
public class Motherboard extends Component
{
	public Motherboard()
	{
		super("Motherboard", "", "", 0, 1);
		numComponents = 5;
		compArr = new Component[numComponents];
		compArr[0] = new Component("CPU", "CPU", "", 0, 1);
		compArr[1] = new Component("Memory", "Memory", "", 0, 1);
		compArr[2] = new Component("Video Card", "VideoCard", "", 0, 1);
		compArr[3] = new Component("Sound Card", "SoundCard", "", 0, 1);
		compArr[4] = new Component("Ethernet Card", "EthernetCard", "", 0, 1);

	}

	public double cost()
	{
		double total = 0;
		for (int i=0; i<numComponents; i++)
		{
			total += compArr[i].cost();
		}
		return total;
	}

	/**
	Prints out all the components of Motherboard including the cost.
	The cost for Motherboard is the summation of all the components.
	*/
	public String toString()
	{
		String str = "Motherboard:  cost: $" + cost() + "\n";
		for (int i=0; i<numComponents; i++)
		{
			str += "              " + compArr[i].toString() + "\n";
		}
		return str;
	}

	/**
	Same as toString() except it prints out index for each components
	so that the user can enter the index to choose the component.
	*/
	public String toStringNum()
	{
		String str = "Motherboard:  cost: $" + cost() + "\n";
		for (int i=0; i<numComponents; i++)
		{
			str += "  " + (i+1) + ". " + compArr[i].toString() + "\n";
		}
		return str;
	}

	/**
	User can select 1 to numComponents + 1.
	numComponents + 1 is to exit.
	*/
	public void selectComponent(JDBCAdapter dt)
	{
		boolean input = false;	// true if input option number is valid.
		BufferedReader in;
		String inputLine;
		int num = 1;

		if (numComponents == 1)  return;

		while (input == false)
		{
			System.out.println("\nEnter 1 to " + numComponents +
				".  Enter " + (numComponents + 1) + " to Go Up.");
			in = new BufferedReader(new InputStreamReader(System.in));
			try
			{
				inputLine = in.readLine();
				num = Integer.parseInt(inputLine);
				if ( (num >= 1) && (num <= (numComponents + 1)) )
				{
					//input = true;

					if (num == (numComponents + 1))
					{
						//input = true;
						return;
					}
					else
					{
						// get the database table name.
						// Create a query and display the db table contents in JTable.
						compArr[num-1].displayTable(dt);

						// Let user choose one
						System.out.println("\nEnter id from the table\n");
						inputLine = in.readLine();
						int id = Integer.parseInt(inputLine);

						// query the table with the id to get name and cost
						// corresponding to the id.
						String tableName = compArr[num-1].getTableName();
						String name = dt.getName(id, tableName);
						name = name.trim();
						double cost = dt.getCost(id, tableName);

						// set the name cost for the component
						compArr[num-1].setName(name);
						compArr[num-1].setCost(cost);

						// list the PC system
						System.out.print(toStringNum());

						// close the JTable
						compArr[num-1].closeTable();
					}
				}
				else
				{
					System.out.println("Invalid input: " + num);
				}
			}
			catch (IOException e)
			{
				System.out.println("Exception name = " + e);
			}
		}
	}


	private Component[] compArr;

	//for debug
	public static void main(String[] args)
	{
		Motherboard mb1 = new Motherboard();
		System.out.print(mb1.toString());
		System.out.println("123456789012345678901234567890");
		System.out.println(mb1.cost());
	}
}
