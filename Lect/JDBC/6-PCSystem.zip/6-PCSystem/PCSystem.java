// PCSystem.java

import java.io.*;

/**
PC System
*/
public class PCSystem extends Component
{

	/**
	It sets the components of PC System and connects to the pointbase database
	where all the possible components are stored.
	*/
	public PCSystem()
	{
		super("PCSystem", "", "", 0, 1);
		numComponents = 6;

		compArr = new Component[numComponents];
		compArr[0] = new Case();
		compArr[1] = new Component("Keyboard", "Keyboard", "", 0, 1);
		compArr[2] = new Component("Mouse", "Mouse", "", 0, 1);
		compArr[3] = new Component("Monitor", "Monitor", "", 0, 1);
		compArr[4] = new Component("Printer", "Printer", "", 0, 1);
		compArr[5] = new Component("Speaker", "Speaker", "", 0, 1);

		URL = "jdbc:pointbase://localhost:9092/sample";
		driver = "com.pointbase.jdbc.jdbcUniversalDriver";
		user = "pbpublic";
		passwd = "pbpublic";

		dt = new JDBCAdapter(URL, driver, user, passwd);
	}

	public double cost()
	{
		double total = 0;
		for (int i=0; i<numComponents; i++)
		{
			total += compArr[i].cost();
		}
		return total;
	}

	/**
	Prints out all the components of PCSystem.
	*/
	public String toString()
	{
		String str = "\nPCSystem:  Cost: $" + cost() + "\n";
		for (int i=0; i<numComponents; i++)
		{
			str += "    " + (i+1) + ". " + compArr[i].toString() + "\n";
		}
		return str;
	}


	/**
	User can select 1 to numComponents + 1.
	numComponents + 1 is to exit.
	*/
	public void selectComponent()
	{
		boolean input = false;	// true if input option number is valid.
		BufferedReader in;
		String inputLine;
		int num = 1;

		if (numComponents == 1)
		{
			return;
		}

		while (input == false)
		{
			System.out.println(toString());
			System.out.println("\nEnter 1 to " + numComponents +
				".  Enter " + (numComponents + 1) + " to Exit.");
			in = new BufferedReader(new InputStreamReader(System.in));
			try
			{
				inputLine = in.readLine();
				num = Integer.parseInt(inputLine);
				if ( (num >= 1) && (num <= (numComponents + 1)) )
				{
					//input = true;

					if (num == (numComponents + 1))
					{
						//break;
						input = true;
						System.exit(0);
					}
					else if (num == 1) // Case
					{
						System.out.println(compArr[num-1].toStringNum());
						compArr[num-1].selectComponent(dt);
					}
					else
					{
						// Get the database table name.
						// Create a query and display the db table contents in JTable.
						compArr[num-1].displayTable(dt);

						// Let user choose one
						System.out.println("\nEnter id from the table\n");
						inputLine = in.readLine();
						int id = Integer.parseInt(inputLine);

						String tableName = compArr[num-1].getTableName();
						String name = dt.getName(id, tableName);
						name = name.trim();
						double cost = dt.getCost(id, tableName);

						// set the name cost for the component
						compArr[num-1].setName(name);
						compArr[num-1].setCost(cost);

						// list the PC system
						System.out.print(toString());

						// close the JTable
						compArr[num-1].closeTable();
					}
				}
				else
				{
					System.out.println("Invalid input: " + num);
				}
			}
			catch (IOException e)
			{
				System.out.println("Exception name = " + e);
			}
		}
	}


	// array of Component
	private Component[] compArr;

	private JDBCAdapter dt;
	private String URL;
	private String driver;
	private String user;
	private String passwd;

	/**
	It displays PC components and asks the user to choose one.  If the corresponding
	database table exists, it displays the contents of the table in the separate
	window.  Then it asks the user to choose one entry.  The name and cost of the
	chosen component will be displayed along with the whole PCSystem.  The cost
	will be accumulated.
	Assumption:  The user can choose one instance of each PC component at one time.
	*/
	public static void main(String[] args)
	{
		PCSystem pc = new PCSystem();
		pc.selectComponent();
	}

}
