// Case.java

import java.io.*;

/**
Case
*/
public class Case extends Component
{
	public Case()
	{
		super("Case", "", "", 0, 1);
		numComponents = 5;
		compArr = new Component[numComponents];
		compArr[0] = new Component("Power Supply", "PowerSupply", "", 0, 1);
		compArr[1] = new Motherboard();
		compArr[2] = new Component("Floppy Drive", "FloppyDrive", "", 0, 1);
		compArr[3] = new Component("Hard Drive", "HardDrive", "", 0, 1);
		compArr[4] = new Component("CD Drive", "CDDrive", "", 0, 1);

	}

	public double cost()
	{
		double total = 0;
		for (int i=0; i<numComponents; i++)
		{
			total += compArr[i].cost();
		}
		return total;
	}

	/**
	Prints out all the components of Case including the cost.
	The cost for Case is the summation of all the components.
	*/
	public String toString()
	{
		String str = "Case:  Cost: $" + cost() + "\n";
		for (int i=0; i<numComponents; i++)
		{
			//str += "  " + (i+1) + ". " + compArr[i].toString() + "\n";
			str += "          " + compArr[i].toString() + "\n";
		}
		return str;
	}

	/**
	Same as toString() except it prints out index for each components
	so that the user can enter the index to choose the component.
	*/
	public String toStringNum()
	{
		String str = "Case:  Cost: $" + cost() + "\n";
		for (int i=0; i<numComponents; i++)
		{
			str += "  " + (i+1) + ". " + compArr[i].toString() + "\n";
			//str += "          " + compArr[i].toString() + "\n";
		}
		return str;
	}


	/**
	User can select 1 to numComponents + 1.
	numComponents + 1 is to exit.
	*/
	public void selectComponent(JDBCAdapter dt)
	{
		boolean input = false;	// true if input option number is valid.
		BufferedReader in;
		String inputLine;
		int num = 1;

		if (numComponents == 1)  return;

		while (input == false)
		{
			System.out.println("\nEnter 1 to " + numComponents +
				".  Enter " + (numComponents + 1) + " to Go Up.");
			in = new BufferedReader(new InputStreamReader(System.in));
			try
			{
				inputLine = in.readLine();
				num = Integer.parseInt(inputLine);
				if ( (num >= 1) && (num <= (numComponents + 1)) )
				{
					//input = true;

					if (num == (numComponents + 1))
					{
						//input = true;
						return;
					}
					else if (num == 2) // Motherboard
					{
						System.out.println(compArr[num-1].toStringNum());
						compArr[num-1].selectComponent(dt);
						// list the Case menu
						System.out.print(toStringNum());
					}
					else
					{
						// get the database table name.
						// Create a query and display the db table contents in JTable.
						compArr[num-1].displayTable(dt);

						// Let user choose one
						System.out.println("Enter id from the table\n");
						inputLine = in.readLine();
						int id = Integer.parseInt(inputLine);

						// query the table with the id to get name and cost
						// corresponding to the id.
						String tableName = compArr[num-1].getTableName();
						String name = dt.getName(id, tableName);
						name = name.trim();

						double cost = dt.getCost(id, tableName);

						// set the name cost for the component
						compArr[num-1].setName(name);
						compArr[num-1].setCost(cost);

						// list the PC system
						System.out.println(toStringNum());

						// close the JTable
						compArr[num-1].closeTable();
					}
				}
				else
				{
					System.out.println("Invalid input: " + num);
				}
			}
			catch (IOException e)
			{
				System.out.println("Exception name = " + e);
			}
		}
	}


	//private int numComponent;

	// array of Component
	private Component[] compArr;

	//for debug
	public static void main(String[] args)
	{
		Case c1 = new Case();
		System.out.println(c1.toString());
		//System.out.println(c1.cost());
	}

}
