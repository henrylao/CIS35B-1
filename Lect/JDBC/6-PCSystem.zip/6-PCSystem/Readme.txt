PCSystem Readme.txt

FILES:

PCSystem.java		Main program
			Uses command window for the user interaction and display.
			The content of each component table is displayed separate
			JTable window after the user selects a PC component.

Output.txt		Output from PCSystem in the command window.

TableOutput.doc		Contains each output of component tables.
			They are displayed after the user selects a PC component.