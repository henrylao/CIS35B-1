// Component.java

import javax.swing.*;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Dimension;

/**
PC Component
*/
public class Component {

	/**
	constructor
	@param cat Category of the PC component
	@param dbNam Database table name associated with the component
	@param nam name of the component
	@param p price of the component
	@param numComps number of sub-components belonging to this component
	*/
	public Component(String cat, String dbNam, String nam, double p, int numComps)
	{
		category = cat;
		DBTableName = dbNam;
		name = nam;
		price = p;
		numComponents = numComps;
	}

	// constructor
	public Component()
	{
		category = "";
		DBTableName = "";
		name = "";
		price = 0;
		numComponents = 1;
	}

	public double cost()
	{
		return price;
	}

	public String toString()
	{
		return category + ": " + name + "   Cost: $" + price;
	}

	public String toStringNum()
	{
		return "1. " + category + ": " + name + "  Cost: " + price;
	}

	public void selectComponent(JDBCAdapter dt)
	{
	}

	/**
	Displays the database table contents using JTable.
	@param dt JDBC Adapter
	*/
	public void displayTable(JDBCAdapter dt)
	{
		if (DBTableName == "")  return;

		frame = new JFrame("Table: " + DBTableName);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {System.exit(0);}});
		String query = "SELECT * FROM " + DBTableName;
		dt.executeQuery(query);

		// Create the table
		JTable tableView = new JTable(dt);

		JScrollPane scrollpane = new JScrollPane(tableView);
		scrollpane.setPreferredSize(new Dimension(700, 300));

		frame.getContentPane().add(scrollpane);
		frame.pack();
		frame.setVisible(true);
	}

	/**
	*/
	public String getTableName()
	{
		return DBTableName;
	}

	public void setName(String nam)
	{
		name = nam;
	}

	public void setCost(double cost)
	{
		price = cost;
	}

	public void closeTable()
	{
		frame.dispose();
	}


	private String category;	// used to print out in the cmd window
	private String DBTableName;	// associated DB Table Name if exists
	private String name;
	private double price;

	private JFrame frame;

	protected int numComponents;

	// for debug
	public static void main(String[] args)
	{
		Component c1 = new Component("Printer", "Printer", "HP Laser Printer",
		150.00, 1);
		System.out.println(c1.toString());
		System.out.println(c1.cost());

		Component c2 = new Component();
		System.out.println(c2.toString());
		System.out.println(c2.cost());

		Component c3 = new Component("Hard Drive", "HardDrive", "", 0, 1);
		System.out.println(c3.toString());
		System.out.println(c3.cost());
	}
}