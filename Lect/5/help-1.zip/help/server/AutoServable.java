

package server;

public interface AutoServable {

	public void serve(int port);

}
