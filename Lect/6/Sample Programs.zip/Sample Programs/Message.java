//Message.java
package beans;

public class Message
{
  public String msg() {
    return "Hello from JSP!";
  }

  public Message() 
  {
  }
}
