package client;

public interface AutoClient {
	public void client(String host, int port);
}
