//============================================================================
// Project     : Lab5
//Name        : FixAuto.java
//Author      : Tianqi Yang
// Time        : 5/29/2019
//IDE         : Eclipse
//Description : it is the interface of FixAuto 
//============================================================================
package adapter;

public interface FixAuto {
	public String fix();
	public String fix(int i);
}