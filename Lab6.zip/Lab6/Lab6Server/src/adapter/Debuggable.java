package adapter;

public interface Debuggable {
	final boolean DEBUG = true;
}
