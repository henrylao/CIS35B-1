//============================================================================
// Project     : Lab5
// Name        : Helper401to500.java
// Author      : Tianqi Yang
// Time        : 5/29/2019
// IDE         : Eclipse
//Description : it is helper functions that fix error number from 401 to 500 
// that occurs in thread package
//============================================================================
package exception;

public class Helper401to500 {

}
