//============================================================================
// Project     : Lab5
//Name        : Helper101to200.java
//Author      : Tianqi Yang
//Time        : 5/29/2019
//IDE         : Eclipse
//Description : it is helper functions that fix error number from 101 to 200 
// that occurs in model package
//============================================================================
package exception;

public class Helper101to200 {
	String fix101() {
		return null;
	}
}
